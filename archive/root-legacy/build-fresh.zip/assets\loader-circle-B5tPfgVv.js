import{c as e}from"./createLucideIcon-Dty4-Q0T.js";const c=e("LoaderCircleIcon",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);export{c as L};
