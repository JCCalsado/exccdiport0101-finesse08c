import{c as o}from"./createLucideIcon-Dty4-Q0T.js";const e=o("ChevronDownIcon",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);export{e as C};
