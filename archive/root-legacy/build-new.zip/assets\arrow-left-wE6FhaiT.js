import{c as e}from"./createLucideIcon-DMfuU0-h.js";const r=e("ArrowLeftIcon",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]]);export{r as A};
