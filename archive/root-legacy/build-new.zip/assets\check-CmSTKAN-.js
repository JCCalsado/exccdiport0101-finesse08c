import{c}from"./createLucideIcon-DMfuU0-h.js";const o=c("CheckIcon",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);export{o as C};
